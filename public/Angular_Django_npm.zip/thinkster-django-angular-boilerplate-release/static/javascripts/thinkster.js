angular
  .module('thinkster', []);
