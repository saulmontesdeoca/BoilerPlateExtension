from flask import Blueprint

app = Blueprint('auth', __name__, template_folder=None)
