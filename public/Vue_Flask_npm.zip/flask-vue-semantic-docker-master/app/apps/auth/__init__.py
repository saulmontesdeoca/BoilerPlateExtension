from .bp import app  # noqa
