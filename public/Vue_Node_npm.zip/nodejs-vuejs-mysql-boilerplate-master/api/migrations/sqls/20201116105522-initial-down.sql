/* Replace with your SQL commands */

DROP TABLE IF EXISTS `permission`;

DROP TABLE IF EXISTS `permission_user`;

DROP TABLE IF EXISTS `setting`;

DROP TABLE IF EXISTS `todo`;

DROP TABLE IF EXISTS `user`;
