const config = require('dotenv').config();

module.export = config;
