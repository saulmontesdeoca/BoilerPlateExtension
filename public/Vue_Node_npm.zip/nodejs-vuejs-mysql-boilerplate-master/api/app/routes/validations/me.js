const meGet = require('./me/get');
const mePatch = require('./me/patch');

module.exports = {
  meGet,
  mePatch
};
