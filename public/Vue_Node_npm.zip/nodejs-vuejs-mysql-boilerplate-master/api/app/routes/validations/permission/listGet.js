module.exports = {
  q: {
    in: ['query'],
    optional: { options: { nullable: false } },
    escape: true
  }
};
