
DEBUG = True
SECRET_KEY = 'temporary_secret_key'  # make sure to change this

SQLALCHEMY_DATABASE_URI = 'sqlite:////tmp/angular_flask.db'
