import React from 'react';

export const Home = () =>
    <section>
        <div className="container text-center">
            <h1>Hello</h1>
        </div>
    </section>;
