from application.app import app

app = app
